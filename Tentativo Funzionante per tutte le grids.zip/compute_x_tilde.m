function x_tilde = compute_x_tilde(spanning_trees_matrix, x_FL, bifurcation_line, spanning_trees_root_matrix, n_lines, n_spanning_trees)

if bifurcation_line ~= 0
    for s = 1:1:n_spanning_trees
        for l = n_lines:-1:1
            if spanning_trees_root_matrix(s,bifurcation_line) == 1 && spanning_trees_root_matrix(s,l) == 1
                max_line = l;
                break;
            end
        end
    end
end

% disp(bifurcation_line);

range = (n_lines - length(spanning_trees_matrix(1,:)) + 1):n_lines;

x_tilde = spanning_trees_matrix * x_FL(range,:); 

x_tilde(:,max_line+1:n_lines) = zeros();
% disp(spanning_trees_matrices_opt2);