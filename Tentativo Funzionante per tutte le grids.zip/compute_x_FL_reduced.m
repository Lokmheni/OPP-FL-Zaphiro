function x_FL_reduced = compute_x_FL_reduced(x_FL, bifurcation, max_line)

x_FL_reduced = x_FL;

for l = max(max_line):-1:bifurcation
    x_FL_reduced(l, :) = [];
    x_FL_reduced(:, l) = []; 
end