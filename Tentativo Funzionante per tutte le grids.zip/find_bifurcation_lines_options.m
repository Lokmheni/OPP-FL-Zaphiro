function bifurcation_lines_options = find_bifurcation_lines_options(idx_from, idx_line, bifurcation)

opt = 0;

for j = 1:1:length(idx_from)
    if idx_from(j) == bifurcation
        opt = opt + 1;
        options(opt) = idx_line(j);
    end
end

bifurcation_lines_options = options;
