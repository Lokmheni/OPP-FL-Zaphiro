function ending_lines = find_ending_lines(spanning_trees_root_matrix, bifurcations_vector, bifurcation_lines_options, n_bifurcation_lines_options, n_spanning_trees, n_lines, n_bifurcations)


for bifurcation_idx = 1:1:n_bifurcations

bifurcation = bifurcations_vector(bifurcation_idx);

    for bifurcation_line_idx = 1:1:n_bifurcation_lines_options{bifurcation_idx}

        bifurcation_line_option = bifurcation_lines_options{bifurcation_idx}(bifurcation_line_idx);
        ending_lines{bifurcation_idx}{bifurcation_line_idx} = zeros();
        for s = 1:1:n_spanning_trees
            for l = n_lines:-1:1
                if spanning_trees_root_matrix(s,bifurcation_line_option) == 1 && spanning_trees_root_matrix(s,l) == 1
                    ending_lines{bifurcation_idx}{bifurcation_line_idx} = vertcat(ending_lines{bifurcation_idx}{bifurcation_line_idx}, l);
                    break;
                end
            end
        end
    end


end


end