function bifurcation_points = find_bifurcations(idx_from)
    % Find unique indices and their counts
    [unique_indices, ~, idx_counts] = unique(idx_from);
    counts = accumarray(idx_counts, 1);

    % Find indices with more than one occurrence
    potential_bifurcations = unique_indices(counts > 1);

    % Initialize bifurcation points array
    bifurcation_points = [];

    % Iterate through potential bifurcation points
    for i = 1:numel(potential_bifurcations)
        idx = potential_bifurcations(i);
        occurrences = find(idx_from == idx);

        % Check if the index occurs at multiple positions
        if numel(occurrences) > 1
            bifurcation_points = [bifurcation_points; idx];
        end
    end
    bifurcation_points = unique(bifurcation_points);
end
