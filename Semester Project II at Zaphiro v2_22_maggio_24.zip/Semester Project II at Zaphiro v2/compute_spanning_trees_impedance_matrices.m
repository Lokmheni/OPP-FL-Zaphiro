function spanning_trees_impedance_matrices = compute_spanning_trees_impedance_matrices(spanning_trees_impedance_root_matrix, bifurcations_vector, bifurcation_lines_options, max_ending_lines, n_bifurcation_lines_options, n_bifurcations, n_spanning_trees, n_lines)


for bifurcation_idx = 1:1:n_bifurcations

    for bifurcation_line_option_idx = 1:1:n_bifurcation_lines_options{bifurcation_idx}
        
        bifurcation = bifurcations_vector(bifurcation_idx);
        bifurcation_line_option = bifurcation_lines_options{bifurcation_idx}(bifurcation_line_option_idx);

        spanning_trees_impedance_matrices{bifurcation_idx}{bifurcation_line_option_idx} = spanning_trees_impedance_root_matrix;
        
        for s = n_spanning_trees:-1:1
            if spanning_trees_impedance_root_matrix(s, bifurcation_line_option) == 0
                spanning_trees_impedance_matrices{bifurcation_idx}{bifurcation_line_option_idx}(s,:) = [];
            end
        end
        
        for line = n_lines : -1 : max_ending_lines{bifurcation_idx}{bifurcation_line_option_idx} + 1
            spanning_trees_impedance_matrices{bifurcation_idx}{bifurcation_line_option_idx}(:,line) = [];
        end
        
        for line = bifurcation_line_option - 1 : -1 : 1
            spanning_trees_impedance_matrices{bifurcation_idx}{bifurcation_line_option_idx}(:,line) = [];
        end
    end

end