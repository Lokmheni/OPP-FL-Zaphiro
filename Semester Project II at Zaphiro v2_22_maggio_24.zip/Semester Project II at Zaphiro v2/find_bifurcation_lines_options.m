function bifurcation_lines_options = find_bifurcation_lines_options(bifurcations_vector, n_bifurcations, idx_from, idx_line)

for i=1:1:n_bifurcations
    options = zeros();
    bifurcation = bifurcations_vector(i);

    opt = 0;

    for j = 1:1:length(idx_from)
        if idx_from(j) == bifurcation
            opt = opt + 1;
            options(opt) = idx_line(j);
        end
    end

    bifurcation_lines_options{i} = options;

    % bifurcation_lines_options{i} = find_bifurcation_lines_options(idx_from, idx_line, bifurcation);
    n_bifurcation_lines{i} = length(bifurcation_lines_options{i});

end