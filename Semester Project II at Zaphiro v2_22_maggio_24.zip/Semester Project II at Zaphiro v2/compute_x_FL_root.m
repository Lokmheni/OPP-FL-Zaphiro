function[x_FL_root] = compute_x_FL_root(spanning_trees_root_matrix, spanning_trees_impedance_root_matrix, Zvect_mag, n_spanning_trees, n_lines)

x_FL_root = zeros(n_lines, n_lines);
Z_cum = zeros(n_lines, n_lines);
span = zeros(n_lines);

for line=1:1:n_lines                                        %iterate over all possible FLs (i.e. over all lines)     
    for j=1:1:n_spanning_trees                              %iterate over all spanning trees
        if spanning_trees_root_matrix(j,line) == 1          %if the line is in the spanning tree, store the spanning tree's impedances
            span = spanning_trees_root_matrix(j,:);
            break
        end
    end


    lower_bound = 0;
    upper_bound = 0;
    for i = 1:1:n_lines
        if any(span(i) == 1) && any(i < line)
            lower_bound = lower_bound + Zvect_mag(i);
            upper_bound = lower_bound + Zvect_mag(line);
        elseif lower_bound == 0
            upper_bound = Zvect_mag(line);
        end
    end

    for row = 1:1:n_lines
        for j=1:1:size(spanning_trees_impedance_root_matrix,1)
            if spanning_trees_root_matrix(j,row)
                Z_cum(row, line) = sum(spanning_trees_impedance_root_matrix(j,1:row-1));
                break
            end
        end

        if span(row) == 1
            if row == line
                x_FL_root(row, line) = 1;
            else
                x_FL_root(row, line) = 0;
            end
        else
            if ((Z_cum(row, line) <= lower_bound && (Z_cum(row, line)+Zvect_mag(row) <= lower_bound)) || (Z_cum(row, line) >= upper_bound))
                x_FL_root(row,line) = 0;
            else 
                if ((Z_cum(row, line) <= lower_bound) && (Z_cum(row, line)+Zvect_mag(row) >= lower_bound)) || ((Z_cum(row, line) >= lower_bound) && (Z_cum(row, line) <= upper_bound))
                    x_FL_root(row,line) = 1;
                end
            end
        end
    end
end
end
