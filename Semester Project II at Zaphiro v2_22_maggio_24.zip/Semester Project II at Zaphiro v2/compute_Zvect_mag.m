function[Zvect_mag] = compute_Zvect_mag(n_lines, R_prime, X_prime, l)
Zvect_mag = zeros(n_lines, 1);
for i=1:n_lines
    Zvect_mag(i) = sqrt(R_prime(i)^2 + X_prime(i)^2)*l(i);
end

% % if there are lines with the same impedance, change them slightly
A = Zvect_mag;

% Detect unique elements and their indices
[~, ~, uniqueIndices] = unique(A);

% Find duplicates
duplicatedIndices = find(histc(uniqueIndices, 1:max(uniqueIndices)) > 1);

% Adjust duplicates
for idx = 1:length(duplicatedIndices)
    % Find indices of each duplicate group
    duplicateGroup = find(uniqueIndices == duplicatedIndices(idx));
    % Adjust each element in the duplicate group by a small percentage
    for j = 2:length(duplicateGroup)
        A(duplicateGroup(j)) = A(duplicateGroup(j)) * (1 + 0.001 * (j - 1));
    end
end

Zvect_mag = A;