function x_FL = compute_x_FL(x_FL_root, max_ending_lines, bifurcation_lines_options, bifurcations_vector, n_bifurcation_lines_options, n_bifurcations, n_lines)

for bifurcation_idx = 1:1:n_bifurcations

    for bifurcation_line_option_idx = 1:1:n_bifurcation_lines_options{bifurcation_idx}
        
        bifurcation = bifurcations_vector(bifurcation_idx);
        bifurcation_line_option = bifurcation_lines_options{bifurcation_idx}(bifurcation_line_option_idx);

        x_FL{bifurcation_idx}{bifurcation_line_option_idx} = x_FL_root;

        for l = n_lines : -1 : max_ending_lines{bifurcation_idx}{bifurcation_line_option_idx} + 1
            x_FL{bifurcation_idx}{bifurcation_line_option_idx}(l,:) = [];
            x_FL{bifurcation_idx}{bifurcation_line_option_idx}(:,l) = [];
        end

        for l = bifurcation_line_option - 1 : -1 : 1
            x_FL{bifurcation_idx}{bifurcation_line_option_idx}(l,:) = [];
            x_FL{bifurcation_idx}{bifurcation_line_option_idx}(:,l) = [];
        end

    end

end