function[Zvect] = compute_Zvect(n_lines, R_prime, X_prime, l)
Zvect = zeros(n_lines, 1);
for i=1:n_lines
    Zvect(i) = (R_prime(i) + 1i*X_prime(i))*l(i);
end