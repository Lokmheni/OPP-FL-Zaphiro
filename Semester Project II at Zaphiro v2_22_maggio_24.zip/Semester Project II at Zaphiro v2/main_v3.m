%% main script for OPP-FL Zaphiro

clear;
close all;

disp(' ');
disp('*************************************************************');
disp('Optimal PMU Placement (OPP) for Fault Location (FL) - Zaphiro');
disp('*************************************************************');
disp(' ');
disp('Lokman Mheni')
disp(' ');
disp('May 2024');
disp(' ');
disp('v3');
disp(' ');



%%  Step 1: Data Loading and preprocessing
disp('STEP 1: Data Loading and preprocessing');
disp(' ');


% Load tab-separated data from file  - choose your desired Test Grid
linedata = load('DATA/Grid parameters Simple_Test_Grid_1.txt', 'FileType', 'text', 'Delimiter', '\t');


disp('Loading line parameters...');
disp(' ');

idx_line    = linedata(:,1);
idx_from    = linedata(:,2);
idx_to      = linedata(:,3);
l           = linedata(:,4);
R_prime     = linedata(:,5);
X_prime     = linedata(:,6);
B_prime     = linedata(:,7);
R_0         = linedata(:,8);
X_0         = linedata(:,9);
B_0         = linedata(:,10);
ampacity    = linedata(:,11);

disp('Printing data...');
disp('');

% Extract information
n_lines = length(idx_from);                                                % number of lines
n_buses = max([idx_from;idx_to]);                                          % number of nodes
n_spanning_trees = n_buses - height(unique(idx_from));                     % number of spanning trees
disp(['The network consists of ' int2str(n_buses) ' buses, ' ...
    int2str(n_lines), ' lines and ' ...
    int2str(n_spanning_trees), ' spanning trees.']);
disp(' ');



%% Step 2: Basic Computations
disp('STEP 2: Basic Computations');
disp('');

% Spanning Trees Root Matrix Computation
disp('Spanning Trees Matrix Computation');
disp('');
spanning_trees_root_matrix = compute_spanning_trees_root_matrix(idx_from, idx_to, idx_line, n_spanning_trees, n_lines, n_buses);
disp(spanning_trees_root_matrix);
disp('');
disp(['Dimensions: ' num2str(size(spanning_trees_root_matrix))]);

% Zvect computation: 1xn_lines vector containing in element i the impedance of line i
Zvect = compute_Zvect(n_lines, R_prime, X_prime, l);
disp('Vector Zvect (containing at entry i the complex impedance of line i):');
disp(['Dimensions: ' num2str(size(Zvect))]);
disp(Zvect);

disp('Vector Zvect_mag (containing at entry i the magnitude of the impedance of line i):');
Zvect_mag = compute_Zvect_mag(n_lines, R_prime, X_prime, l);
disp(['Dimensions: ' num2str(size(Zvect_mag))]);
disp(Zvect_mag);

% Spanning Trees Impedance Root Matrix Computation
disp('Spanning Trees Impedance Root Matrix');
spanning_trees_impedance_root_matrix = compute_spanning_trees_impedance_root_matrix(spanning_trees_root_matrix, Zvect_mag);
disp(spanning_trees_impedance_root_matrix);
disp(['Dimensions: ' num2str(size(spanning_trees_impedance_root_matrix))]);

% Cumulative Impedance Vector
disp('Cumulative Impedance Vector');
Z_cum = compute_Zcum(spanning_trees_impedance_root_matrix, n_spanning_trees, n_lines);
disp(Z_cum);
disp(['Dimensions: ' num2str(size(Z_cum))]);

% Fault Location Vectors Computations
disp('Fault Location Vectors');
x_FL_root = compute_x_FL_root(spanning_trees_root_matrix, spanning_trees_impedance_root_matrix, Zvect_mag, n_spanning_trees, n_lines);
disp(['Dimensions: ' num2str(size(x_FL_root))]);
disp(x_FL_root);


%% Step 3: Select candidate buses for PMU placement
disp('STEP 3: Select candidate buses for PMU placement');
disp('');

% Find bifurcations
disp('Find bifurcations...')
bifurcations_vector = find_bifurcations(idx_from);
disp('Vector of bifurcations: ')
disp(bifurcations_vector);
disp('');

% Preselect the bifurcation nodes as candidates for PMU placement
if ~any(bifurcations_vector == 1)                                           % Always consider placing a PMU in the feeder node
    candidate_PMU_nodes = [1; bifurcations_vector]; 
else
    candidate_PMU_nodes = bifurcations_vector;
end

disp("Candidate buses for PMU placement: ");
disp(candidate_PMU_nodes);
disp(['Dimensions: ' num2str(size(candidate_PMU_nodes))]);

n_bifurcations = length(bifurcations_vector);
n_candidate_PMU_nodes = length(candidate_PMU_nodes);


%% Step 5: "Subgrids" computations
disp('STEP 5: "Subgrids" computations');
disp('');

% Find the lines going out from each bifurcation bus
bifurcation_lines_options = find_bifurcation_lines_options(bifurcations_vector, n_bifurcations, idx_from, idx_line);

for bifurcation_idx = 1:1:n_bifurcations
    disp(['Lines going out from bifurcation node number ' num2str(bifurcations_vector(bifurcation_idx))]);
    disp(bifurcation_lines_options{bifurcation_idx});
    n_bifurcation_lines_options{bifurcation_idx} = length(bifurcation_lines_options{bifurcation_idx});
end

% Find ending lines of each subgrid
ending_lines = find_ending_lines(spanning_trees_root_matrix, bifurcations_vector, bifurcation_lines_options, n_bifurcation_lines_options, n_spanning_trees, n_lines, n_bifurcations);
max_ending_lines = compute_max_ending_lines(ending_lines, n_bifurcation_lines_options, n_bifurcations);


% Compute spanning trees matrices of the subgrids
disp('Compute spanning trees matrices of the subgrids...');
spanning_trees_impedance_matrices = compute_spanning_trees_impedance_matrices(spanning_trees_impedance_root_matrix, bifurcations_vector, bifurcation_lines_options, max_ending_lines, n_bifurcation_lines_options, n_bifurcations, n_spanning_trees, n_lines);

% Compute FL vectors for subgrids
disp('Compute FL vectors for subgrids');
x_FL = compute_x_FL(x_FL_root, max_ending_lines, bifurcation_lines_options, bifurcations_vector, n_bifurcation_lines_options, n_bifurcations, n_lines);


% Display subgrids characteristics
for bifurcation_idx = 1:1:n_bifurcations
    disp(['Bifurcation node number ' num2str(bifurcations_vector(bifurcation_idx))]);
    for bifurcation_line_option_idx = 1:1:n_bifurcation_lines_options{bifurcation_idx}
        disp(['Subgrid number ' num2str(bifurcation_line_option_idx)]);
        disp(['(corresponding to line number ' num2str(bifurcation_lines_options{bifurcation_idx}(bifurcation_line_option_idx)) ')']);
        disp('');
        disp(['Maximum Ending Line: ' num2str(max_ending_lines{bifurcation_idx}{bifurcation_line_option_idx})]);
        disp('');
        disp('Spanning Trees Matrix: ');
        disp(spanning_trees_impedance_matrices{bifurcation_idx}{bifurcation_line_option_idx});
        disp('FL Vectors: ')
        disp(x_FL{bifurcation_idx}{bifurcation_line_option_idx})
    end
end

% Compute z_tilde matrices
disp('z_tilde matrices computation');

z_tilde_root = spanning_trees_impedance_root_matrix * x_FL_root;
disp('Root z_tilde: ');
disp(z_tilde_root);
disp('');

for bifurcation_idx = 1:1:n_bifurcations
    for bifurcation_line_option_idx = 1:1:n_bifurcation_lines_options{bifurcation_idx}
        z_tilde{bifurcation_idx}{bifurcation_line_option_idx} = spanning_trees_impedance_matrices{bifurcation_idx}{bifurcation_line_option_idx} * x_FL{bifurcation_idx}{bifurcation_line_option_idx};
    end
end

for bifurcation_idx = 1:1:n_bifurcations
    disp(['Bifurcation node number ' num2str(bifurcations_vector(bifurcation_idx))]);
    for bifurcation_line_option_idx = 1:1:n_bifurcation_lines_options{bifurcation_idx}
        disp(['Subgrid number ' num2str(bifurcation_line_option_idx)]);
        disp(['(corresponding to line number ' num2str(bifurcation_lines_options{bifurcation_idx}(bifurcation_line_option_idx)) ')']);
        disp('');
        disp('z_tilde: ');
        disp(z_tilde{bifurcation_idx}{bifurcation_line_option_idx});
    end
end

%% Step 6: Compute number of possible FLs, when placing a PMU in one PMU node candidate
disp('STEP 6: Compute number of possible FLs, when placing a PMU in one PMU node candidate');
disp('');

if ~any(bifurcations_vector == 1)                           % Always consider placing a PMU in the feeder node
    possible_FLs_single_PMU{1} = possible_FLs_root;
end

possible_FLs_single_PMU = compute_possible_FLs_single_PMU(z_tilde, bifurcations_vector, bifurcation_lines_options, max_ending_lines, n_bifurcation_lines_options, n_bifurcations, n_lines);



for bifurcation_idx = 1:1:n_bifurcations
    bifurcation = bifurcations_vector(bifurcation_idx);
    disp(['Bifurcation node number ' num2str(bifurcations_vector(bifurcation_idx))]);
    disp(['Number of possible FLs when a single PMU is placed at node : ' num2str(bifurcation)]);
    disp(possible_FLs_single_PMU{bifurcation_idx});
end


%% Step 7: PMU Placement
disp('STEP 7: PMU Placement');
disp('');

disp(["Maximum allowed number of possible FLs: " num2str(max_FLs_allowed)]);
disp('');

