function possible_FLs_single_PMU = compute_possible_FLs_single_PMU(z_tilde, bifurcations_vector, bifurcation_lines_options, max_ending_lines, n_bifurcation_lines_options, n_bifurcations, n_lines)

if ~any(bifurcations_vector == 1)
    start = 2;
else
    start = 1;
end

for bifurcation_idx = start:1:n_bifurcations
    possible_FLs_single_PMU{bifurcation_idx} = zeros(1, n_lines);
end

for bifurcation_idx = start:1:n_bifurcations
    bifurcation = bifurcations_vector(bifurcation_idx);

    for bifurcation_line_option_idx = 1:1:n_bifurcation_lines_options{bifurcation_idx}
        bifurcation_line_option = bifurcation_lines_options{bifurcation_idx}(bifurcation_line_option_idx);
        
        unique_count = zeros();
        for i = 1:1:length(z_tilde{bifurcation_idx}{bifurcation_line_option_idx}(1, :))
            arr = z_tilde{bifurcation_idx}{bifurcation_line_option_idx}(:, i);
            nonZeroValues = arr(arr ~= 0);
            unique_values = unique(nonZeroValues);
            unique_count(i) = length(unique_values);
        end
        
        possible_FLs_single_PMU{bifurcation_idx}(bifurcation_line_option:max_ending_lines{bifurcation_idx}{bifurcation_line_option_idx}) = unique_count;
    
    end
end

