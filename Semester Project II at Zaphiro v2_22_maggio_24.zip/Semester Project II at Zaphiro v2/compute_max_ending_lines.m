function max_ending_lines = compute_max_ending_lines(ending_lines, n_bifurcation_lines_options, n_bifurcations)

for bifurcation_idx = 1:1:n_bifurcations
    for bifurcation_line_idx = 1:1:n_bifurcation_lines_options{bifurcation_idx}
        max_ending_lines{bifurcation_idx}{bifurcation_line_idx} = max(ending_lines{bifurcation_idx}{bifurcation_line_idx});
    end
end