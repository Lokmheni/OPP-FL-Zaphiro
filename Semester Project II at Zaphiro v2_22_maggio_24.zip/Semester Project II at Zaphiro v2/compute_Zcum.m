function[Zcum] = compute_Zcum(spanning_trees_impedance_root_matrix, n_spanning_trees, n_lines)

Z_cum = zeros(n_lines, 1);

for line = 2:1:n_lines
    for s = 1:1:n_spanning_trees
        if spanning_trees_impedance_root_matrix(s, line) ~= 0
            Zcum(line) = sum(spanning_trees_impedance_root_matrix(s, 1:line-1));
            break
        end
    end
end