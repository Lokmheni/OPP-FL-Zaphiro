function max_line = compute_max_line_v2(bifurcation_line, spanning_trees_root_matrix, n_spanning_trees, n_lines)

for s = 1:1:n_spanning_trees
    for l = n_lines:-1:1
        if spanning_trees_root_matrix(s,bifurcation_line) == 1 && spanning_trees_root_matrix(s,l) == 1
            max_line = l;
            break;
        end
    end
end
end