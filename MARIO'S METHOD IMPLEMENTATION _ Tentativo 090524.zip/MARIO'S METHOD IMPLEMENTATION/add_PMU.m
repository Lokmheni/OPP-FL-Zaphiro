function PMU_placement = add_PMU(x, PMU_placement, best, n_bifurcations, bifurcations_vector, spanning_trees_impedance_matrix_reduced, max_line, spanning_trees_root_matrix, span_trees_root_impedance_matrix, bifurcation_lines_options, x_FL, possible_FLs_basic, possible_FLs_root, n_lines, n_spanning_trees)

% start by placing a PMU at feeder + 1 more PMU at a bifurcation

max_possible_FLs = n_spanning_trees * ones(1, n_bifurcations);
sum_possible_FLs = n_lines * n_spanning_trees * ones(1, n_bifurcations);

for i = 1:1:n_bifurcations
    bifurcation = bifurcations_vector(i);
    isNotEqual = true;
    for j = 1:numel(PMU_placement)
        if isequal(bifurcation, PMU_placement{j})
            isNotEqual = false;
            break;
        end
    end
    if ~isNotEqual

        spanning_trees_impedance_matrix_reduced{i} = compute_spanning_trees_impedance_matrix_reduced(spanning_trees_root_matrix, span_trees_root_impedance_matrix, bifurcation, max_line{i}, bifurcation_lines_options{i}, n_lines, n_spanning_trees);
                                                                                                     
        x_FL_reduced{i} = compute_x_FL_reduced(x_FL, bifurcation, max_line{i});
    
        x_tilde_reduced{i} = spanning_trees_impedance_matrix_reduced{i} * x_FL_reduced{i};
        
        for j = 1:1:size(x_tilde_reduced{i}, 2)
            unique_entries_reduced{i}(j) = count_unique_entries(x_tilde_reduced{i}(:,j));
        end
    
        for j = 1:1:n_lines
            if j < bifurcation
                possible_FLs{i}(j) = unique_entries_reduced{i}(j);
            else
                if j >= bifurcation && j <= max(max_line{i})
                    possible_FLs{i}(j) = possible_FLs_basic{i}(j);
                else
                    if j > max(max_line{i})
                        possible_FLs{i}(j) = unique_entries_reduced{i}(j - max(max_line{i}) + bifurcation - 1);
                    end
                end
            end
        end
        sum_possible_FLs(i) = sum(possible_FLs{i});
        max_possible_FLs(i) = compute_max_possible_FLs(possible_FLs{i});
    end
end

possible_FLs = [possible_FLs_root, possible_FLs];



if any(max_possible_FLs > x)
    add_PMU(x, PMU_placement, n_bifurcations, bifurcations_vector, spanning_trees_impedance_matrix_reduced, x_tilde_reduced, max_line);
else
    PMU_placement = [PMU_placement, bifurcation];
    for j = 1:1:n_bifurcations
        if sum_possible_FLs(i) < best
           best = sum_possible_FLs(i);
           best_placement = PMU_placement;
        end
        disp('Possible FLs');
        disp(possible_FLs{j});
        disp('Max possible FLs');
        disp(max_possible_FLs(j));
        disp('Sum possible FLs');
        disp(sum_possible_FLs(j));
        disp('PMU placement');
        disp(PMU_placement);
    end
end
