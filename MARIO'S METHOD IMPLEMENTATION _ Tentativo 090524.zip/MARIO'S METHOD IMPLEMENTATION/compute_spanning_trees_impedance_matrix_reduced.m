function span_trees_impedance_matrix_reduced = compute_spanning_trees_impedance_matrix_reduced(spanning_trees_root_matrix, span_trees_root_impedance_matrix, bifurcation, max_line, bifurcation_lines_options, n_lines, n_spanning_trees)

span_trees_impedance_matrix_reduced = span_trees_root_impedance_matrix;

% disp(bifurcation)
if max(max_line) ~= n_lines
    for k = bifurcation:1:max(max_line)
        span_trees_impedance_matrix_reduced(:,k) = 0;
    end
end
for s = n_spanning_trees:-1:1
    for j = 1:1:length(bifurcation_lines_options)
        if spanning_trees_root_matrix(s,bifurcation_lines_options(j))
            if bifurcation_lines_options(j) == bifurcation
                s_bif = s;
            end
            % disp(bifurcation_lines_options{i}(j));
            span_trees_impedance_matrix_reduced(s, :) = [];
        end
    end
end
span_trees_impedance_matrix_reduced = vertcat(span_trees_root_impedance_matrix(s_bif,:), span_trees_impedance_matrix_reduced);
span_trees_impedance_matrix_reduced(1,bifurcation:end) = zeros();

for l  = max(max_line):-1:bifurcation
    span_trees_impedance_matrix_reduced(:,l) = [];
    % disp(span_trees_impedance_matrix_reduced);
end
