function spanning_trees_impedance_matrix = compute_spanning_trees_matrix(bifurcation_lines_options, span_trees_root_impedance_matrix, n_lines, n_spanning_trees)

spanning_trees_impedance_matrix = span_trees_root_impedance_matrix(:,bifurcation_lines_options:n_lines);
for s=1:1:n_spanning_trees
    if span_trees_root_impedance_matrix(s, bifurcation_lines_options) == 0
        spanning_trees_impedance_matrix(s,:) = zeros(1, size(spanning_trees_impedance_matrix,2));
    end
end