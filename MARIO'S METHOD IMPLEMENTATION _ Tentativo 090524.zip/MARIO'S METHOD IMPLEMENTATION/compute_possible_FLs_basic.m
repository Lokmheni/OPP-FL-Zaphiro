function possible_FLs_basic = compute_possible_FLs_basic(unique_entries_root, bifurcation_lines_options, bifurcations_vector, x_tilde, max_line, n_bifurcations, n_lines)

for i=n_bifurcations:-1:1
    unique_entries{i} = zeros(size(unique_entries_root));
    bifurcation = bifurcations_vector(i);
    disp(['Bifurcation node ' num2str(bifurcation)]);
    for j = 1:1:length(bifurcation_lines_options{i})
        for k = 1:1:n_lines
            if (k >= bifurcation_lines_options{i}(j)) && (k <= max_line{i}(j))
                unique_entries{i}(k) = count_unique_entries(x_tilde{i}{j}(:, k));
            end
            % if k < bifurcation - 1
            %     unique_entries{i}(k) = 0;
            % end
        end

    end
    possible_FLs_basic{i} = unique_entries{i};
    disp(possible_FLs_basic{i});
end