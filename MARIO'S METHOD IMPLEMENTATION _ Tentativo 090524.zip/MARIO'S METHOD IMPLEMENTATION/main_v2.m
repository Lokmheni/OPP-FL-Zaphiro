%% main script for OPP-FL Zaphiro

clear;
close all;

disp(' ');
disp('*************************************************************');
disp('Optimal PMU Placement (OPP) for Fault Location (FL) - Zaphiro');
disp('*************************************************************');
disp(' ');
disp('May 2024');
disp(' ');

%%  Step 1: Data Loading and preprocessing
disp('STEP 1: Data Loading and preprocessing');
disp(' ');

% Load tab-separated data from file  - choose your desired Test Grid
linedata = load('DATA/Grid parameters S-EG.txt', 'FileType', 'text', 'Delimiter', '\t');
% linedata = load('DATA/Grid parameters E-F.txt', 'FileType', 'text', 'Delimiter', '\t');
% linedata = load('DATA/Grid parameters E-L.txt', 'FileType', 'text', 'Delimiter', '\t');
% linedata = load('DATA/Grid parameters N-J18J19.txt', 'FileType', 'text', 'Delimiter', '\t');
% linedata = load('DATA/Grid parameters S-BM.txt', 'FileType', 'text', 'Delimiter', '\t');
% linedata = load('DATA/Grid parameters S-BN.txt', 'FileType', 'text', 'Delimiter', '\t');
% linedata = load('DATA/Grid parameters S-ET.txt', 'FileType', 'text', 'Delimiter', '\t');
% linedata = readtable('DATA/Grid parameters IEEE 34.txt', 'FileType', 'text', 'Delimiter', '\t');

disp('Loading line parameters...');
disp(' ');

idx_line    = linedata(:,1);
idx_from    = linedata(:,2);
idx_to      = linedata(:,3);
l           = linedata(:,4);
R_prime     = linedata(:,5);
X_prime     = linedata(:,6);
B_prime     = linedata(:,7);
R_0         = linedata(:,8);
X_0         = linedata(:,9);
B_0         = linedata(:,10);
ampacity    = linedata(:,11);

disp('Printing data...');
disp('');
% Print the data 
%linedata = RenameVars(linedata);
% Uncomment to see the table containing the lines values 
%disp(linedata)

% Extract information
n_lines = length(idx_from);                                                % number of lines
n_buses = max([idx_from;idx_to]);                                          % number of nodes
n_spanning_trees = n_buses - height(unique(idx_from));                     % number of spanning trees
disp(['The network consists of ' int2str(n_buses) ' buses, ' ...
    int2str(n_lines), ' lines and ' ...
    int2str(n_spanning_trees), ' spanning trees.']);
disp(' ');


% Compute and Plot the Graph associated with the network
disp('Computing and displaying the Graph associated with the network...');
disp('');
table = table(idx_line, idx_from, idx_to, l, R_prime, X_prime, B_prime, R_0, X_0, B_0, ampacity);
G = GraphComputation_and_Plot(table);

%% Step 2: Basic Computations

% Spanning Trees Matrix Computation

disp('Spanning Trees Matrix Computation');
disp('');

spanning_trees_root_matrix = spanning_trees_matrix_computation(idx_from, idx_to, idx_line, n_spanning_trees, n_lines, n_buses);

disp('Spanning Trees Matrix: number of spanning trees x number of buses');

disp(spanning_trees_root_matrix);
disp(['Dimensions: ' num2str(size(spanning_trees_root_matrix))]);

% Zbus Matrix Computation -- Please note that shunt admittances are neglected and only branch elements are considered

% Adjacency matrix computation
disp('Adjacency Matrix computation');
disp('');

adjacency_matrix = Adjacency_matrix_computation(n_buses, n_lines, idx_from, idx_to);

disp('Adjacency Matrix: number of branches x number of buses')
disp(adjacency_matrix);
disp(['Dimensions: ' num2str(size(adjacency_matrix))]);

Zbus = compute_Zbus(n_buses, n_lines, idx_from, idx_to, R_prime, X_prime, l, B_prime, R_0, X_0, B_0);
disp('Zbus Matrix:');
disp(Zbus);
disp(['Dimensions: ' num2str(size(Zbus))]);

% Zvect computation: 1xn_lines vector containing in element i the impedance of line i
Zvect = compute_Zvect(n_buses, n_lines, idx_from, idx_to, R_prime, X_prime, l, B_prime, R_0, X_0, B_0);
disp('Vector Zvect (containing at entry i the complex impedance of line i):');
disp(['Dimensions: ' num2str(size(Zvect))]);
disp(Zvect);

disp('Vector Zvect_mag (containing at entry i the magnitude of the impedance of line i):');
Zvect_mag = compute_Zvect_mag(n_buses, n_lines, idx_from, idx_to, R_prime, X_prime, l, B_prime, R_0, X_0, B_0);
disp(['Dimensions: ' num2str(size(Zvect_mag))]);
disp(Zvect_mag);

span_trees_root_impedance_matrix = span_trees_root_impedance_matrix_computation(spanning_trees_root_matrix, Zvect_mag);
disp('Spanning Trees Root impedance matrix');
disp(['Dimensions: ' num2str(size(span_trees_root_impedance_matrix))]);
disp(span_trees_root_impedance_matrix);

Zcum_ST = Zcum_ST_computation(span_trees_root_impedance_matrix, n_lines, n_spanning_trees);
disp('"Cumulative" Spanning Trees impedance matrix');
disp(['Dimensions: ' num2str(size(Zcum_ST))]);
disp(Zcum_ST);

%% Find bifurcations
bifurcations_vector = compute_bifurcations(idx_from);
disp('Looking for bifurcations...');
n_bifurcations = length(bifurcations_vector);
disp(['Number of bifurcations: ' num2str(n_bifurcations)]);

% Preselect the bifurcation nodes as candidates for PMU placement
if ~any(bifurcations_vector == 1)    % Always consider placing a PMU in the feeder mode
    candidates_PMU_nodes = [1; bifurcations_vector]; 
else
    candidates_PMU_nodes = bifurcations_vector;
end

disp("Candidate buses for PMU placements: ");
disp(candidates_PMU_nodes);
disp(['Dimensions: ' num2str(size(candidates_PMU_nodes))]);

n_candidates_PMU_nodes = length(candidates_PMU_nodes);

%% For each bifurcation, find the lines going out
for i=1:1:n_bifurcations
    bifurcation = bifurcations_vector(i);
    bifurcation_lines_options{i} = find_bifurcation_lines_options(idx_from, idx_line, bifurcation);
    disp(['Lines going out from bifurcation node number ' num2str(bifurcation)]);
    disp(bifurcation_lines_options{i});
end

%% For each line going out from a bifurcation, find the corresponding spanning trees matrix
for i=1:1:n_bifurcations
    for j = 1:1:length(bifurcation_lines_options{i})
        spanning_trees_matrices{i}{j}(:,:) = compute_spanning_trees_matrix(bifurcation_lines_options{i}(j), span_trees_root_impedance_matrix, n_lines, n_spanning_trees);
        disp(['Spanning Trees Matrix corresponding to Line ' num2str(bifurcation_lines_options{i}(j))]);
        disp(spanning_trees_matrices{i}{j});
    end
end

%% For each "subgrid" going out from a bifurcation, find the max line index
for i=1:1:n_bifurcations
    for j = 1:1:length(bifurcation_lines_options{i})
        %max_line{i} = zeros(1, length(bifurcation_lines_options{i}));
        max_line{i}(j) = compute_max_line_v2(bifurcation_lines_options{i}(j), spanning_trees_root_matrix, n_spanning_trees, n_lines);
    end
    disp(max_line{i});
end

%% Compute FL vectors matrix
disp('Fault location vectors matrix:');
x_FL = FL_matrix_computation(n_spanning_trees, n_lines, spanning_trees_root_matrix, span_trees_root_impedance_matrix, Zvect_mag);
disp(['Dimensions: ' num2str(size(x_FL))]);
disp(x_FL);

%% Compute x_tilde matrices (containing Fault Location uniqueness vectors)

x_tilde_root = span_trees_root_impedance_matrix*x_FL;
for i = 1:1:size(x_tilde_root, 2)
    possible_FLs_root(i) = count_unique_entries(x_tilde_root(:,i));
end

for i=1:1:n_bifurcations
    for j = 1:1:length(bifurcation_lines_options{i})
        x_tilde{i}{j} = compute_x_tilde(spanning_trees_matrices{i}{j}, x_FL, bifurcation_lines_options{i}(j), spanning_trees_root_matrix, n_lines, n_spanning_trees);
        disp(['FL Uniqueness vectors for line ' num2str(bifurcation_lines_options{i}(j))]);
        disp(x_tilde{i}{j});
    end
end


%% Compute, for each bifurcation, the maximum possible FLs if a PMU was placed only in that node

% PMU placed at feeder
for j =1:1:n_lines
    unique_entries_root(j) = count_unique_entries(x_tilde_root(:, j));
end

% PMU placed in a bifurcation node
possible_FLs_basic = compute_possible_FLs_basic(unique_entries_root, bifurcation_lines_options, bifurcations_vector, x_tilde, max_line, n_bifurcations, n_lines);


%% PMU placement

x = 2;      % Max number of allowed possible FLs
best = n_spanning_trees;
PMU_placement = [];
for i = 1:1:n_bifurcations
    span_trees_impedance_matrix_reduced{i} = span_trees_root_impedance_matrix;
    x_FL_reduced{i} = x_FL;
end
PMU_placement = add_PMU(x, PMU_placement, best, n_bifurcations, bifurcations_vector, span_trees_impedance_matrix_reduced, max_line, spanning_trees_root_matrix, span_trees_root_impedance_matrix, bifurcation_lines_options, x_FL, possible_FLs_basic, possible_FLs_root, n_lines, n_spanning_trees);

disp(PMU_placement);

%% Display intermediate results
% disp('**********Results using PMU at feeder plus one more PMU****************')
% for i = 1:1:n_bifurcations
%     PMU_node = candidates_PMU_nodes(i);
%     disp(['PMU at feeder and node ' num2str(candidates_PMU_nodes(i))]);
%     disp('Number of possible FLs: ');
%     disp(possible_FLs{i});
%     disp('');
%     disp(['Maximum number of FLs: ' num2str(max_possible_FLs{i})]);
%     disp('');
% end

%%






